<?php 	
abstract class ETF
{
	public function proccess(){}
	protected function __construct()
	{

	}
}

class A 
{
	public $name='George';
	private function __construct()
	{

	}
}
class B extends A
{
	public function __construct()
	{
		
	}	
}

$a = new B;
echo $a->name;