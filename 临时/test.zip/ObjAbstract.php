<?php 
abstract class A
{
	public function say()
	{
		echo '我说我说我说';
	}
	abstract   protected function dodo1();
}
// $b=new A;exit;
 class B extends A
{	
	public function dodo1()
	{
		echo 'wowoowowowo';
	}
	static  function dodo()
	{
		echo '我做我做我做';
	}
}
$e= new B;
$e->say();
$e::dodo();
echo '<hr>';
class C extends A
{	
	private $name = 'George_Bai';
	static $age = 18;
	protected  function dodo1()
	{
		echo '静态的,不动的';
	}
	public function __get($paramete)
	{
		echo $this->$paramete;
	}
	public function __invoke()
	{
		echo '<hr>我是函数了!!!';
	}
	public function __call($funcname,$paramete)
	{
		// var_dump();
		if(property_exists($this,'dodo1')){
			echo $funcname.'这个方法不存在';
		}else{
			$this->$funcname($paramete);
		}
	}
}
$f= new C;
$f->say();
$f->name;
	function C ()
	{
		$c =  new C;
		$c();
	}
echo '<hr>';
// $f->dodo1();
// $f->adssf();
var_dump(property_exists('C','name'));
echo C::$age;