<?php
class A
{
	public $age = 18;
}
class C
{
	public $age = 18;
}
class B
{
	public function __construct()
	{
		$a = new A();
		// $b = $a->age=20;
		// $b = new C();
		$b = new A();
		// $b = $a;
		// $b->age=20;
		// echo $a->age.'and'.$b->age;
		if ($a==$b) {
			echo 'YES';
		}else{
			echo 'NO';
		}	
	}
	
}
$exec = new B();