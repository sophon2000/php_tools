<?php 
	function maopao($arr)
	{
		for ($i=0,$len=count($arr);$i< $len-1;$i++) {
			$p = $i ;
			for ($j=$i+1; $j < $len; $j++) { 
				if ($arr[$p]>$arr[$j]) {
					$tmp = $arr[$j];
					$arr[$j]=$arr[$p];
					$arr[$p]=$tmp;
				}
			}

		}
		return $arr;
	}
	$arr=array('1','4','2','7','5','85','5','4','1');
	$j = maopao($arr);
	var_dump($j);