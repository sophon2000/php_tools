<?php 
	phpinfo();
 ?>