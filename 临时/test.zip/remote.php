<?php 
echo getenv('REMOTE_ADDR');
echo $_SERVER['REMOTE_ADDR'];
echo '<hr>';
// var_dump($_SERVER);
echo session_save_path();
