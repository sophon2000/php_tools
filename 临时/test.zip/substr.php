<?php 
function GBsubstr($string, $start, $length) {
    if(strlen($string)>$length){
     $str=null;
     $len=$start+$length;
     for($i=$start;$i<$len;$i++){
	    if(ord(substr($string,$i,1))>0xa0){
	     	$str.=substr($string,$i,2);
	     	$i++;
	    }else{
 			$str.=substr($string,$i,1);
     	}
    }
   		return $str.'...';
    }else{
   		return $string;
   }
}
$a = '我和你';
echo mb_substr($a, 0,1,'UTF-8').'<hr>';
echo utf8_encode(mb_substr($a, 0,1,'GBK'));
echo '<hr>';
echo substr($a,0,6);
