<?php 
class A
{
	private static $name='George';
}
class B extends A
{
	public static $name='Buymax';
}
$exec = new B;
// echo $exec->name;
echo $exec::$name;