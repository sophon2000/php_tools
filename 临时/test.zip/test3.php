<?php 
class A
{
	private $name='aaa';
}
class B extends A
{
	private $name1='11';
	private $name12='11';
	public function getName()
	{
		echo $this->name12;
		echo 'end';
		 return $this->name1;
	}
}
$c = new B;
 // $c->getName();
 echo $c->getName();
 // var_dump($c->getName()) ;
 echo    '333';