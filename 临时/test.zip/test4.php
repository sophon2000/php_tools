<?php 
class A
{
	public final  function demo()
	{
		echo '本宗';
	}
}
class B extends A
{
	public function demo1()
	{
		echo '假的';
	}
}
$c = new B;
$c->demo();
$c->demo1();