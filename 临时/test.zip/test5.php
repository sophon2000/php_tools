<?php 

const HDD = '大屌丝';
var_dump(defined('HDD'));
define('HBD', 'sss');
echo HBD;