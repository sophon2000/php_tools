<?php 
class A
{
	public $name='George';
	private static $obj = null;
	protected function __construct()
	{

	}
	public static function getObj()
	{
		if (!self::$obj) {
			self::$obj= new self;
		}
		return self::$obj;
	}
}
// $b = new A;
// echo $b->name;
$b = A::getObj();
echo $b->name;
echo '<hr>';
$a = A::getObj();
echo $a->name='ff';
echo '<hr>';
$c = A::getObj();
echo $c->name;
echo '$b'.$b->name;
if ($a==$b) {
	echo '是同一个对象';
}else{
	echo '不是同一个对象';
}