<?php 
$a = 1483604095;
echo date('Y-m-d H:i:s',$a);