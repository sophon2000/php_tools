<?php 
$a = fopen('http://www.imooc.com', 'rb');
$b = stream_get_contents($a);
// touch('./imooc.html');
// $file = fopen('./imooc.html', 'w');
// var_dump(fread($file,$b));
echo file_put_contents('./imooc.html', $b);
// print_r($b);