<?php 
$a = '<?xml version="1.0" encoding="UTF-8"?>
	  <name>我是名字</name>
	  <age>18</age>
	  <sex>man</sex>
	  <description>这就是我的描述</description>';
echo $a;
$p = xml_parser_create();
xml_Parse_into_struct($p,$a,$val,$index);
xml_parser_free($p);
$result = array();
print_r($val);
print_r($index);
exit;
//下面的遍历方式有bug隐患
for ($i=0; $i<3; $i++) {
  $result[$i] = array();
  $result[$i]["extra"] = $values[$tags["EXTRA"][$i]]["value"];
}
print_r($result);
